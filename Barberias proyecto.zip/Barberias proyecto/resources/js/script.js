document.querySelector("#btnMenu").addEventListener("click", mostrarMenu)
function mostrarMenu () {
    let menu = document.querySelector("#menu").value
    
}